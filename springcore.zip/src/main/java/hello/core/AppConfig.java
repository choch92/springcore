package hello.core;

import hello.core.discount.DiscountPolicy;
import hello.core.discount.FixDiscountPolicy;
import hello.core.discount.RateDiscountPolicy;
import hello.core.member.MemberService;
import hello.core.member.MemberServiceImpl;
import hello.core.member.MemoryMemberRepository;
import hello.core.order.OrderService;
import hello.core.order.OrderServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/*공연기획자*/
/*구체 클래스를 선택, 배역에 맞는 담당 배우를 선택, 어플리케이션이 어떻게 동작해야 할지 전체 구성을 책임짐*/
@Configuration
public class AppConfig {

    // @Bean memberService -> new MemoryMemberRepository() 를 호출한다.
    // @Bean orderService ->  new MemoryMemberRepository() 를 호출
    // 결과적으로 각각 다른 2개의 MemoryMemberRepository 가 생성되면서 싱글톤이 깨지는 것 처럼 보인다.
    // 스프링 컨테이너는 이 문제를 어떻게 해결할까?

    //우리의 생각 호출순서
    //call AppConfig.memberService
    //call AppConfig.memberRepository
    //call AppConfig.memberRepository
    //call AppConfig.orderService
    //call AppConfig.memberRepository

    //실제 코드 호출 순서 (모든 비밀은 @Configuration 을 적용한 AppConfig 에 있다)
    //call AppConfig.memberService
    //call AppConfig.memberRepository
    //call AppConfig.orderService

    /* @Bean이 붙은 메서드마다 이미 스프링 빈이 존재하면 존재하는 빈을 반환하고,
    스프링 빈이 없으면 생성해서 스프링 빈으로 등록하고 반환하는 코드가 동적으로 만들어진다.
    덕분에 싱글톤이 보장되는 것이다.*/

    @Bean
    public MemberService memberService(){
        System.out.println("call AppConfig.memberService");
        return new MemberServiceImpl(memberRepository());
    }

    @Bean
    public MemoryMemberRepository memberRepository() {
        System.out.println("call AppConfig.memberRepository");
        return new MemoryMemberRepository();
    }

    @Bean
    public OrderService orderService(){
        System.out.println("call AppConfig.orderService");
        return new OrderServiceImpl(memberRepository(), discountPolicy());
    }

    @Bean
    public DiscountPolicy discountPolicy(){
        /*return new FixDiscountPolicy();*/
        return new RateDiscountPolicy();
    }

}
