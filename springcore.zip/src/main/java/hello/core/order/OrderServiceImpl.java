package hello.core.order;

import hello.core.discount.DiscountPolicy;
import hello.core.member.Member;
import hello.core.member.MemberRepository;
import hello.core.member.MemoryMemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
// 롬복 라이브러리가 제공하는 @RequiredArgsConstructor 기능을 사용하면 final이 붙은 필드를 모아서 생성자를 자동으로 만들어준다
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService{

    // 생성자 주입을 사용하면 필드에 final 키워드를 사용할 수 있다. 그래서 생성자에서 혹시라도 값이 설정되지 않는 오류를 컴파일 시점에 막아준다.
    //  수정자 주입을 포함한 나머지 주입 방식은 모두 생성자 이후에 호출되므로, 필드에 final 키워드를 사용할 수 없다.
    //  오직 생성자 주입 방식만 final 키워드를 사용할 수 있다
    private final MemberRepository memberRepository;
    private final DiscountPolicy discountPolicy;

    /*이전에 AppConfig에서는 @Bean 으로 직접 설정 정보를 작성했고, 의존관계도 직접 명시했다.
    이제는 이런 설정 정보 자체가 없기 때문에, 의존관계 주입도 이 클래스 안에서 해결해야 한다.
    @Autowired 를 사용하면 생성자에서 여러 의존관계도 한번에 주입받을 수 있다.*/
    /*생성자 주입(@Autowired) : 생성자 호출시점에 딱 1번만 호출되는 것이 보장된다, 불변, 필수 의존관계에 사용*/
    /*중요! 생성자가 딱 1개만 있으면 @Autowired를 생략해도 자동 주입 된다. 물론 스프링 빈에만 해당한다.*/
/*    public OrderServiceImpl(MemberRepository memberRepository, 생성자 자동 주입 예시 -> @Qualifier("mainDiscountPolicy") DiscountPolicy discountPolicy) {
        System.out.println("1. memberRepository + discountPolicy = " + memberRepository);
        this.memberRepository = memberRepository;
        this.discountPolicy = discountPolicy;
    }*/

    /*수정자 주입(setter 주입) : setter라 불리는 필드의 값을 변경하는 수정자 메서드를 통해서 의존관계를 주입하는 방법이다*/
    /*선택, 변경 가능성이 있는 의존관계에 사용, 선택, 변경 가능성이 있는 의존관계에 사용*/
    /*@Autowired(required = false)
    public void setMemberRepository(MemberRepository memberRepository) {
        System.out.println("3. memberRepository = " + memberRepository);
        this.memberRepository = memberRepository;
    }
    @Autowired(required = false)
    public void setDiscountPolicy(DiscountPolicy discountPolicy) {
        System.out.println("2. discountPolicy = " + discountPolicy);
        this.discountPolicy = discountPolicy;
    }*/

    /*일반 메서드 주입 : 한번에 여러 필드를 주입 받을 수 있다, 일반적으로 잘 사용하지 않는다*/
    /*@Autowired
    public void init(MemberRepository memberRepository, DiscountPolicy discountPolicy) {
        this.memberRepository = memberRepository;
        this.discountPolicy = discountPolicy;
    }*/

    @Override
    public Order createOrder(Long memberId, String itemName, int itemPrice) {
        Member member = memberRepository.findById(memberId);
        int discountPrice = discountPolicy.discount(member, itemPrice);

        return new Order(memberId,itemName,itemPrice,discountPrice);
    }

    // 테스트 용도
    public MemberRepository getMemberRepository() {
        return memberRepository;
    }
}
