package hello.core.lifecycle;

import org.junit.jupiter.api.Test;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

public class BeanLifeCycleTest {

    @Test
    public void lifeCycleTest(){
        //스프링 컨테이너 생성(스프링 컨테이너를 생성할 때는 구성 정보[LifeCycleConfig.class]를 지정해주어야 한다)
        ConfigurableApplicationContext ac = new AnnotationConfigApplicationContext(LifeCycleConfig.class);
        NetworkClient client = ac.getBean(NetworkClient.class);
        ac.close();
    }

    @Configuration
    // 스프링 빈의 이벤트 라이프사이클
    // 스프링 컨테이너 생성 -> 스프링 빈 생성 -> 의존관계 주입 -> 초기화 콜백(빈이 생성되고, 빈의 의존관계 주입이 완료된 후 호출)
    // -> 사용 -> 소멸전 콜백(빈이 소멸되기 직전에 호출) -> 스프링 종료
    static class LifeCycleConfig {
        // 아래 빈에 설정하는 방식
        // 1. 메서드 이름을 자유롭게 줄 수 있다
        // 2. 코드가 아니라 설정 정보를 사용하기 때문에 코드를 고칠 수 없는 외부 라이브러리에도 초기화, 종료 메서드를 적용할 수 있다
        // 3. 스프링 빈이 스프링 코드에 의존하지 않는다
        /*@Bean(initMethod = "init", destroyMethod = "close")*/

        // 아래 빈에 설정하는 방식
        // 1. @PostConstruct, @PreDestroy 애노테이션 특징
        // 2. 최신 스프링에서 가장 권장하는 방법이다. 애노테이션 하나만 붙이면 되므로 매우 편리하다.
        // 3. 패키지를 잘 보면 javax.annotation.PostConstruct 이다. 스프링에 종속적인 기술이 아니라 JSR-250라는 자바 표준이다.
        //    따라서 스프링이 아닌 다른 컨테이너에서도 동작한다.
        //    유일한 단점은 외부 라이브러리에는 적용하지 못한다는 것이다. 외부 라이브러리를 초기화, 종료 해야 하면 @Bean의 기능을 사용하자.
        @Bean
        public NetworkClient networkClient() {
            NetworkClient networkClient = new NetworkClient();
            networkClient.setUrl("http://hello-spring.dev");
            return networkClient;
        }
    }
}
